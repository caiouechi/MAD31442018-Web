var initialTime = $("#time-typing").text();
var field = $(".field-typing");

$(document).ready(function(){
    updateLengthText();
    initializeCounters();
    initializeTimer();
    initializeMarks();
    $("#button-restart").click(restartGame);

});

function updateLengthText() {
var text = $(".text").text();
var numWords = text.split(" ").length;
var lengthText = $("#length-text");
lengthText.text(numWords);
}

function initializeCounters() {
field.on("input", function() {
var content = field.val();
var qtWords = content.split(/\S+/).length - 1;
    $("#count-words").text(qtWords);
    var qtCaracters = content.length;
    $("#count-caracters").text(qtCaracters);
});
}

/* CODE REFACTORED ...
   When time is over call endGame and add the new record */
function initializeTimer() {
var timeLeft = $("#time-typing").text();
field.one("focus", function() {
var timerID = setInterval(function() {
    timeLeft--;
    $("#time-typing").text(timeLeft);
    if (timeLeft < 1) {
        clearInterval(timerID);
        endGame();
    }
}, 1000);
});
}

function restartGame() {
    field.attr("disabled", false);
    field.val("");
    $("#count-words").text("0");
    $("#count-caracters").text("0");
    $("#time-typing").text(initialTime);
    initializeTimer();
    field.toggleClass("field-disable");
    field.removeClass("margin-red");
    field.removeClass("margin-green");

}

function initializeMarks() {
    var text = $(".text").text();
    field.on("input", function() {
        var typed = field.val();
        var comparable = text.substr(0 , typed.length);

        if(typed == comparable) {
            field.addClass("margin-green");
            field.removeClass("margin-red");
        } else {
            field.addClass("margin-red");
            field.removeClass("margin-green");
        }
    });
}

/* Adding Score record feature */
function insertScore() {
    /* Built-in fuction "FIND" */
    var bodyTable = $(".score").find("tbody");
    var user = "Marcos";
    var numWords = $("#count-words").text();
    /* Buiding the line */
    var line = "<tr>"+
                    "<td>"+ user + "</td>"+
                    "<td>"+ numWords + "</td>"+
                "</tr>";
    /* Adding the new line
       We can use "append" (in the end) and "prepend" (in the begining) */
    bodyTable.prepend(line);
}

/* Function created to support close the game and add the new line */
function endGame() {
  field.attr("disabled", true);
  field.toggleClass("field-disable");
  insertScore();
}

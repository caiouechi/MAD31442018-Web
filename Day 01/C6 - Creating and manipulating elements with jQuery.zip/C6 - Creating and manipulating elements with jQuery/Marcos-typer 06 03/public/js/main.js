/* Add a solution to have a remove behaviour in fixed lines or in new lines
    We can only add events (JS) to Elements HTML, not to strings */

var initialTime = $("#time-typing").text();
var field = $(".field-typing");

$(document).ready(function(){
    updateLengthText();
    initializeCounters();
    initializeTimer();
    initializeMarks();
    $("#button-restart").click(restartGame);

});

function updateLengthText() {
var text = $(".text").text();
var numWords = text.split(" ").length;
var lengthText = $("#length-text");
lengthText.text(numWords);
}

function initializeCounters() {
field.on("input", function() {
var content = field.val();
var qtWords = content.split(/\S+/).length - 1;
    $("#count-words").text(qtWords);
    var qtCaracters = content.length;
    $("#count-caracters").text(qtCaracters);
});
}

function initializeTimer() {
var timeLeft = $("#time-typing").text();
field.one("focus", function() {
var timerID = setInterval(function() {
    timeLeft--;
    $("#time-typing").text(timeLeft);
    if (timeLeft < 1) {
        clearInterval(timerID);
        endGame();
    }
}, 1000);
});
}

function restartGame() {
    field.attr("disabled", false);
    field.val("");
    $("#count-words").text("0");
    $("#count-caracters").text("0");
    $("#time-typing").text(initialTime);
    initializeTimer();
    field.toggleClass("field-disable");
    field.removeClass("margin-red");
    field.removeClass("margin-green");

}

function initializeMarks() {
    var text = $(".text").text();
    field.on("input", function() {
        var typed = field.val();
        var comparable = text.substr(0 , typed.length);

        if(typed == comparable) {
            field.addClass("margin-green");
            field.removeClass("margin-red");
        } else {
            field.addClass("margin-red");
            field.removeClass("margin-green");
        }
    });
}

function insertScore() {
    var bodyTable = $(".score").find("tbody");
    var user = "Marcos";
    var numWords = $("#count-words").text();
    /*
    var buttonRemove = "<a href='#'><i class='small material-icons'>delete</i></a>";
    var line = "<tr>"+
                    "<td>"+ user + "</td>"+
                    "<td>"+ numWords + "</td>"+
                    "<td>"+ buttonRemove + "</td>"+
                "</tr>";
    */

    /* Adding a line via create Element */
    var line = newLine(user, numWords);
    /* Adding a behaviour now in an Element not in a string */
    line.find(".button-remove").click(removeLine);

    bodyTable.prepend(line);
}

function endGame() {
  field.attr("disabled", true);
  field.toggleClass("field-disable");
  insertScore();
}

/* CODE REFACTORED */
function removeLine (event) {
    event.preventDefault();
    $(this).parent().parent().remove();
}

/* Adding create a newLine */
function newLine(user, numWords){

    /* Build a line */
    var line = $("<tr>");

    /* Build the collums */
    var columnUser   = $("<td>").text(user);
    var columnWords  = $("<td>").text(numWords);
    var columnRemove = $("<td>");

    /* Build the last collumn */
    var link = $("<a>").attr("href","#").addClass("button-remove");
    var icon = $("<i>").addClass("small").addClass("material-icons").text("delete");

    // Icon inside <a>
    link.append(icon);

    // <a> inside <td>
    columnRemove.append(link);

    // All columns <td> inside <tr>
    line.append(columnUser);
    line.append(columnWords);
    line.append(columnRemove);

    return line;
}
